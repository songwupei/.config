#!/bin/sh
ICON=" "
# printf "$ICON%s" "$(date '+%a, %b %d, %R')"
printf "$ICON%s" "$(date '+%a, %b %d, %R')"
