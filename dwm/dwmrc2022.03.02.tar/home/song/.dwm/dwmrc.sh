#!/bin/sh
# slock
## 设置60秒锁屏，并使用slock
## slock 快捷键为win(Mod4)+l
xset s 5m &
${HOME}/.dwm/xsidle.sh  slock & 
