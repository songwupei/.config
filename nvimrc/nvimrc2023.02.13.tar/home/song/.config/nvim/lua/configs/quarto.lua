local M = {}

function M.config()
    -- Setup quarto.
    local quarto = require 'quarto'
    quarto.setup({
        lspFeatures = {
        enabled = true,
        languages = {'python', 'r'},
        diagnostics = {
            enabled = true,
            triggers = { "BufWrite" }
        },
        completion = {
            enabled = true
        }
        }
    })
end

return M
