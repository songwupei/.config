local M = {}

M.border = { "╭", "─", "╮", "│", "╯", "─", "╰", "│" }

return M
