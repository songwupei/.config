return {
  -- common dependencies
  { 'nvim-lua/plenary.nvim' },
}
